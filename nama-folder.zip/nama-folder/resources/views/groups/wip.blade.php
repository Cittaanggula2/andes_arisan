@extends('layouts.group')

@section('subtitle', trans('group.detail'))

@section('content-group')
Development in progress.
@endsection
