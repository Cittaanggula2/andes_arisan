<?php

return [
    'dashboard'                 => 'Dashboard',
    'your_groups'               => 'List Grup Anda',
    'your_outstanding_payments' => 'Tunggakan Pembayaran Anda',
];
